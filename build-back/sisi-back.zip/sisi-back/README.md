# projetosisi

Para clonar o projeto faça:

git clone https://github.com/alunofg/sisi-back.git

Versão do Java: Java 8

Versão do Eclipse: Eclipse Photon
  
