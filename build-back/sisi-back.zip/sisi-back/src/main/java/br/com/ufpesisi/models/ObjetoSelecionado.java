package br.com.ufpesisi.models;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ObjetoSelecionado {
	
	@Id
	private long id;
/*
	private long id;

	private BoletimOcorrencia boletimOcorrencia;
	
	private String objeto;
	
	private String observacaoObjeto;
*/
	
}
