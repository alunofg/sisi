package br.com.ufpesisi.models;

import br.com.ufpesisi.models.enums.DominioGenero;
import br.com.ufpesisi.models.enums.DominioRaca;
import br.com.ufpesisi.models.enums.DominioSimNao;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Usuario {

    @Id
	private String cpf;

	@Column(nullable=false, length=50) 
	private String nome;

	@Column(name="data_nascimento")
	private Date dataNascimento;

	@Column(nullable=false, length=50)
	private String email;

	@Enumerated(EnumType.STRING)
	@Column(nullable=false, length=15)
	private DominioGenero genero;

	@Enumerated(EnumType.STRING)
	@Column(nullable=true, length=20) 
	private DominioRaca raca;
	
	@Enumerated(EnumType.STRING)
	@Column
	private DominioSimNao sn_passaporte;
	
	public Usuario() {
		
	}
	
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

    public DominioGenero getGenero() {
        return genero;
    }

    public void setGenero(DominioGenero genero) {
        this.genero = genero;
    }

    public DominioRaca getRaca() {
        return raca;
    }

    public void setRaca(DominioRaca raca) {
        this.raca = raca;
    }
    
    public DominioSimNao getSn_passaporte(DominioSimNao sn_passaporte) {
    	return  sn_passaporte;
    }
    
    public void setSn_passaporte(DominioSimNao sn_passaporte) {
    	this.sn_passaporte = sn_passaporte;
    }
}
