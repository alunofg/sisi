package br.com.ufpesisi.models.enums;

public enum DominioRaca {

	/**
	 * Criação da Classe enum Raça
	 * @paran args
	 * @author EvioMarcio
	 */
	
	BRANCA,
	PRETA,
	PARDA,
	AMARELA,
	INDIGENA,
	NAO_DECLARADA;
	
	
}
