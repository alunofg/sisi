package br.com.ufpesisi.repository;

import br.com.ufpesisi.models.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, String> {

     Usuario findByEmail (String email);

}



