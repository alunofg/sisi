package br.com.ufpesisi.models.enums;

public enum DominioSimNao {
	
	/**
	 * Criação da Classe enum Genero
	 * @paran args
	 * @author EvioMarcio
	 */

	SIM("S"),
	NAO("N");
	
	private String valorSimNao;

	private DominioSimNao(String valor) {
		this.valorSimNao = valor;
	}

	public String getValorSimNao() {
		return valorSimNao;
	}
	
}
