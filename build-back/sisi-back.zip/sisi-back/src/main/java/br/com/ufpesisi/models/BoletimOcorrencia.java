package br.com.ufpesisi.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BoletimOcorrencia {
	
	@Id
	private long id;
	
	@Column(name="dhAbertura")
	private Date dhAbertura;
	
	@Column(name="dhOcorrido")
	private Date dhOcorrido;
	
	@Column(nullable=false, length=60)
	private String localOcorrdio;
	
	@Column(nullable=false, name="descricao_ocorrencia", length=255)
	private String descricaoOcorrencia;
	
	// FALTANDO DEFINIR A ANOTAÇÃO DE RELAÇÃO 
	
	//private List<Testemunhas> testemunhas;
	
	//private List<TipoObjeto> tipoObjeto;
	
	@Column(nullable=false, name="descricao_objeto", length=100)
	private String descricaoObjeto;
	
	@Column(nullable=false, name="descricao_ocorrido", length=255)
	private String descricaoOcorrido;
	
	@Column(nullable=false, name="armaUtilizada", length=30)
	private String armaUtilizada;

	public BoletimOcorrencia() {
		
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getDhAbertura() {
		return dhAbertura;
	}

	public void setDhAbertura(Date dhAbertura) {
		this.dhAbertura = dhAbertura;
	}

	public Date getDhOcorrido() {
		return dhOcorrido;
	}

	public void setDhOcorrido(Date dhOcorrido) {
		this.dhOcorrido = dhOcorrido;
	}

	public String getLocalOcorrdio() {
		return localOcorrdio;
	}

	public void setLocalOcorrdio(String localOcorrdio) {
		this.localOcorrdio = localOcorrdio;
	}

	public String getDescricaoOcorrencia() {
		return descricaoOcorrencia;
	}

	public void setDescricaoOcorrencia(String descricaoOcorrencia) {
		this.descricaoOcorrencia = descricaoOcorrencia;
	}

	public String getDescricaoObjeto() {
		return descricaoObjeto;
	}

	public void setDescricaoObjeto(String descricaoObjeto) {
		this.descricaoObjeto = descricaoObjeto;
	}

	public String getDescricaoOcorrido() {
		return descricaoOcorrido;
	}

	public void setDescricaoOcorrido(String descricaoOcorrido) {
		this.descricaoOcorrido = descricaoOcorrido;
	}

	public String getArmaUtilizada() {
		return armaUtilizada;
	}

	public void setArmaUtilizada(String armaUtilizada) {
		this.armaUtilizada = armaUtilizada;
	}
	
}
