package br.com.ufpesisi.models.enums;

public enum DominioTipoOcorrencia {
	
	
	FURTO("FURTO"),
	ROUBO("ROUBE"),
	ATIVIDADE_SUSPEITA("ATIVIDADE"),
	ARROMBAMENTO("ARRONBAMENTO"),
	RACISMO("RACISMO"),
	ESTUPRO("ESTUPRO"),
	VANDALISMO("VANDALISMO"),
	ASSEDIO_BULLYING("ASSEDIO BULLYING"),
	ASSEDIO_SEXUAL("ASSEDIO SEXUAL"),
	ASSEDIO_STALKING("ASSEDIO STALKING"),
	INCENDIO("INCENDIO"),
	LESAO_CORPORAL("LESAO CORPORAL"),
	MAUS_TRATOS("MAUS TRATOS"),
	OUTROS("OUTROS");
	
	private String TipoOcorrencia;

	private DominioTipoOcorrencia(String valor) {
		this.TipoOcorrencia = valor;
	}

	public String getTipoOcorrencia() {
		return TipoOcorrencia;
	}

}


