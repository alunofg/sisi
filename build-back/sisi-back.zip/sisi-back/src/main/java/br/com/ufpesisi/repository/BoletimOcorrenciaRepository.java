package br.com.ufpesisi.repository;

import br.com.ufpesisi.models.BoletimOcorrencia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoletimOcorrenciaRepository extends JpaRepository<BoletimOcorrencia, Long> {
	
	//BoletimOcorrencia findById (Long Id);

}
