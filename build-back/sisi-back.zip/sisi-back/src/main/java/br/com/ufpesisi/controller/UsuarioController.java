package br.com.ufpesisi.controller;


import br.com.ufpesisi.models.Usuario;
import br.com.ufpesisi.repository.UsuarioRepository;
import com.sun.xml.internal.ws.api.message.ExceptionHasMessage;
import io.swagger.annotations.ApiOperation;
import net.bytebuddy.implementation.bytecode.Throw;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/")
public class UsuarioController {

    @Autowired
    UsuarioRepository usuarioRepository;

    @PostMapping("usuario")
    @ApiOperation(tags = "Usuario", value = "Cria um novo usuario")
    public Usuario created(@RequestBody Usuario usuario) throws Exception {

        Usuario user = this.usuarioRepository.findByEmail(usuario.getEmail());

        if (user != null){
            if(user.getEmail().equals(usuario.getEmail())){
                throw new Exception("Email já cadastrado!");
            }
        }

        this.usuarioRepository.save(usuario);

        return usuario;
    }

    @GetMapping("usuarios/{email}")
    @ApiOperation(tags = "Usuario", value = "Busca um usuario atraves do email")
    public Usuario getByEmail(@PathVariable String email){

        Usuario usuario = this.usuarioRepository.findByEmail(email);

        return usuario;
    }

}
