package br.com.ufpesisi.models.enums;

public enum DominioGenero {

	/**
	 * Criação da Classe enum Genero
	 * @paran args
	 * @author EvioMarcio
	 */


	MASCULINO("M"),
	FEMININO("F"),
	TRANS_MASCULINO("TM"),
	TRANS_FEMININO("TF"),
	INDEFINIDO("I"),
	NAO_DECLARADO("N");


	private String valorSexo;

	private DominioGenero(String valor) {
		this.valorSexo = valor;
	}

	public String getValorSexo() {
		return valorSexo;
	}

}
